"""Run the checks: `python3 tests/run.py` for everything, or name a suite (`popup`, `page`)."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SUITES = {"popup": "popup.py", "page": "page.py"}  # the quick one first

names = sys.argv[1:] or list(SUITES)
unknown = [name for name in names if name not in SUITES]
if unknown:
    sys.exit(f"Unknown suite: {', '.join(unknown)}. Choose from: {', '.join(SUITES)}.")

failed = []
for name in names:
    print(f"\n######## {name}", flush=True)
    # -B: never write __pycache__ into the extension folder
    if subprocess.run([sys.executable, "-B", os.path.join(HERE, SUITES[name])]).returncode:
        failed.append(name)

print("\n" + (f"FAILED: {', '.join(failed)}" if failed else "All suites passed."))
sys.exit(1 if failed else 0)
