"""A small Chrome DevTools Protocol driver over --remote-debugging-pipe (standard library only).

It starts the installed Chrome with a throwaway profile folder, so your own
browser profile is never touched.
"""
import base64
import fcntl
import json
import os
import queue
import shutil
import subprocess
import threading
import time

def find_chrome():
    """The browser binary: $CHROME if set, otherwise the usual install locations."""
    candidates = [
        os.environ.get("CHROME"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        shutil.which("google-chrome"),
        shutil.which("google-chrome-stable"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
    ]
    for path in candidates:
        if path and os.path.exists(path):
            return path
    raise SystemExit("Chrome was not found. Set CHROME to the path of the browser binary.")


class Chrome:
    def __init__(self, profile_dir, args=(), headless=True):
        shutil.rmtree(profile_dir, ignore_errors=True)
        os.makedirs(profile_dir, exist_ok=True)
        to_chrome_r, to_chrome_w = os.pipe()
        from_chrome_r, from_chrome_w = os.pipe()
        # move the child's ends well clear of fds 3/4 before dup2-ing onto them
        hi_r = fcntl.fcntl(to_chrome_r, fcntl.F_DUPFD, 20)
        hi_w = fcntl.fcntl(from_chrome_w, fcntl.F_DUPFD, 20)

        def child_setup():  # Chrome reads commands on fd 3 and writes replies on fd 4
            os.dup2(hi_r, 3)
            os.dup2(hi_w, 4)

        cmd = [
            find_chrome(),
            f"--user-data-dir={profile_dir}",
            "--remote-debugging-pipe",
            "--enable-unsafe-extension-debugging",  # lets Extensions.loadUnpacked install the folder
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-search-engine-choice-screen",
            "--use-mock-keychain",
            "--password-store=basic",
            "--disable-sync",
            "--disable-background-networking",
            "--disable-component-update",
            "--window-size=1280,800",
            *(["--headless=new"] if headless else []),
            *args,
        ]
        self.proc = subprocess.Popen(
            cmd, close_fds=False, preexec_fn=child_setup,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        for fd in (to_chrome_r, from_chrome_w, hi_r, hi_w):
            os.close(fd)
        self._w = os.fdopen(to_chrome_w, "wb", buffering=0)
        self._r = os.fdopen(from_chrome_r, "rb", buffering=0)
        self._id = 0
        self._lock = threading.Lock()
        self._pending = {}
        self.events = queue.Queue()
        self.event_log = []
        threading.Thread(target=self._read_loop, daemon=True).start()

    def _read_loop(self):
        buf = b""
        while True:
            try:
                chunk = self._r.read(65536)
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            while b"\0" in buf:
                raw, buf = buf.split(b"\0", 1)
                if not raw:
                    continue
                msg = json.loads(raw)
                if "id" in msg:
                    slot = self._pending.pop(msg["id"], None)
                    if slot is not None:
                        slot.put(msg)
                else:
                    self.event_log.append(msg)
                    self.events.put(msg)

    def send(self, method, params=None, session=None, timeout=30):
        with self._lock:
            self._id += 1
            mid = self._id
            slot = queue.Queue()
            self._pending[mid] = slot
            msg = {"id": mid, "method": method, "params": params or {}}
            if session:
                msg["sessionId"] = session
            self._w.write(json.dumps(msg).encode() + b"\0")
        try:
            reply = slot.get(timeout=timeout)
        except queue.Empty:
            raise TimeoutError(f"{method} timed out")
        if "error" in reply:
            raise RuntimeError(f"{method}: {reply['error']}")
        return reply.get("result", {})

    def close(self):
        try:
            self.send("Browser.close", timeout=5)
        except Exception:
            pass
        try:
            self.proc.wait(timeout=10)
        except Exception:
            self.proc.kill()


class Tab:
    """One page target, attached in flat mode."""

    def __init__(self, chrome, url="about:blank", new_window=False, background=False):
        self.c = chrome
        params = {"url": "about:blank", "newWindow": new_window, "background": background}
        self.target = chrome.send("Target.createTarget", params)["targetId"]
        self.session = chrome.send(
            "Target.attachToTarget", {"targetId": self.target, "flatten": True}
        )["sessionId"]
        self.cmd("Page.enable")
        self.cmd("Runtime.enable")
        self.cmd("Log.enable")
        if url != "about:blank":
            self.goto(url)

    def cmd(self, method, params=None, timeout=30):
        return self.c.send(method, params, session=self.session, timeout=timeout)

    def goto(self, url, wait=1.0):
        r = self.cmd("Page.navigate", {"url": url})
        time.sleep(wait)
        return r

    def activate(self):
        self.c.send("Target.activateTarget", {"targetId": self.target})

    def js(self, expression, context=None, await_promise=True):
        params = {
            "expression": expression,
            "awaitPromise": await_promise,
            "returnByValue": True,
            "userGesture": True,
        }
        if context is not None:
            params["contextId"] = context
        r = self.cmd("Runtime.evaluate", params)
        if "exceptionDetails" in r:
            raise RuntimeError(json.dumps(r["exceptionDetails"])[:600])
        return r["result"].get("value")

    def contexts(self):
        """Execution contexts seen so far for this tab: {id: (type, name, origin)}."""
        out = {}
        for ev in list(self.c.event_log):
            if ev.get("sessionId") != self.session:
                continue
            if ev["method"] == "Runtime.executionContextCreated":
                ctx = ev["params"]["context"]
                out[ctx["id"]] = (ctx.get("auxData", {}).get("type"), ctx.get("name"), ctx.get("origin"))
            elif ev["method"] == "Runtime.executionContextDestroyed":
                out.pop(ev["params"].get("executionContextId"), None)
            elif ev["method"] == "Runtime.executionContextsCleared":
                out.clear()
        return out

    def ext_context(self, name="Back to Work"):
        """Newest isolated world belonging to the extension's content script."""
        ids = [i for i, (t, n, _o) in self.contexts().items() if t == "isolated" and n == name]
        return max(ids) if ids else None

    def screenshot(self, path, clip=None):
        params = {"format": "png"}
        if clip:
            params["clip"] = {**clip, "scale": 1}
        data = self.cmd("Page.captureScreenshot", params)["data"]
        with open(path, "wb") as f:
            f.write(base64.b64decode(data))

    def close(self):
        try:
            self.c.send("Target.closeTarget", {"targetId": self.target})
        except Exception:
            pass
