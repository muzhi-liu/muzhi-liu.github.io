"""A local HTTPS stand-in for robinhood.com, for testing the extension.

It serves a few static, made-up pages ("Fakehood") and nothing else. The tests
tell Chrome to look up robinhood.com at this server, so nothing is sent to the
real site.
"""
import http.server
import os
import ssl
import subprocess
import threading
import time

DASH = """<!doctype html><html><head><meta charset="utf-8"><title>{title}</title>
<style>
  body {{ margin:0; font:15px/1.5 -apple-system, system-ui, sans-serif; background:{bg}; color:{fg}; }}
  header {{ height:64px; display:flex; align-items:center; gap:28px; padding:0 40px; border-bottom:1px solid {line}; }}
  header b {{ font-size:18px; }} header span {{ opacity:.7; }}
  .wrap {{ display:grid; grid-template-columns: 1fr 340px; gap:40px; max-width:1100px; margin:0 auto; padding:28px 40px; }}
  h1 {{ font-size:40px; margin:0; }} .chg {{ color:#0a8f3c; font-weight:600; }}
  .chart {{ height:260px; margin:22px 0; border-bottom:1px solid {line};
            background: linear-gradient(170deg, transparent 49.4%, #0a8f3c 49.6%, #0a8f3c 50.4%, transparent 50.6%); }}
  .row {{ display:flex; justify-content:space-between; padding:13px 0; border-bottom:1px solid {line}; }}
  .side {{ border:1px solid {line}; border-radius:6px; padding:6px 18px; align-self:start; }}
  .news p {{ margin:10px 0; }}
  a, button {{ font:inherit; margin-right:14px; }}
</style></head><body>
<header><b>Fakehood</b><span>Search</span><span>Rewards</span><span>Investing</span><span>Account</span></header>
<div class="wrap"><main>
  <h1>$48,213.77</h1><div class="chg">+$312.40 (+0.65%) Today</div>
  <div class="chart"></div>
  <div class="row"><span>Buying power</span><b>$1,204.18</b></div>
  <div class="row"><span>Cash</span><b>$1,204.18</b></div>
  <div class="row"><span>Stock lending income</span><b>$3.12</b></div>
  <div class="row"><span>Dividends this year</span><b>$412.90</b></div>
  <div class="news">
    <p><b>Markets close mixed as traders weigh the latest inflation figures and a busy week of earnings ahead of the holiday.</b></p>
    <p>Semiconductor shares slipped 1.8% while utilities and staples finished higher; the ten-year yield was little changed at 4.21%.</p>
    <p>Oil settled at $71.44 a barrel, gold added 0.4% to $2,655.10, and the dollar index edged down 0.2% to 104.31 on the day.</p>
    <p>Analysts expect revenue of $12.4B and earnings of $1.87 per share when the company reports after the bell on Thursday.</p>
    <p>Volume on the consolidated tape came to 11.2 billion shares, slightly below the twenty-day average of 11.9 billion.</p>
  </div>
  <p><a id="full" href="/page2">full navigation</a><a id="excluded" href="/us/en/support">excluded page</a>
     <button id="spa" onclick="history.pushState({{}}, '', '/stocks/AAPL'); document.title='AAPL'">SPA route</button></p>
</main><aside class="side">
  <div class="row"><span>AAPL</span><b>$229.87</b></div><div class="row"><span>MSFT</span><b>$417.02</b></div>
  <div class="row"><span>NVDA</span><b>$138.25</b></div><div class="row"><span>VOO</span><b>$548.61</b></div>
  <div class="row"><span>TSLA</span><b>$321.22</b></div><div class="row"><span>AMZN</span><b>$207.09</b></div>
  <div class="row"><span>GOOG</span><b>$178.35</b></div><div class="row"><span>BRK.B</span><b>$467.40</b></div>
  <div class="row"><span>JPM</span><b>$239.56</b></div><div class="row"><span>COST</span><b>$928.08</b></div>
</aside></div>
{extra}
</body></html>"""

LIGHT = dict(bg="#ffffff", fg="#111111", line="#e3e5e8")
DARK = dict(bg="#000000", fg="#ffffff", line="#30363c")

PAGES = {
    "/": DASH.format(title="Investing", extra="", **LIGHT),
    "/dark": DASH.format(title="Investing (dark)", extra="", **DARK),
    "/page2": DASH.format(title="Page two", extra="", **LIGHT),
    "/stocks/AAPL": DASH.format(title="AAPL", extra="", **LIGHT),
    "/us/en/support": "<!doctype html><title>Support</title><h1>Support article (excluded path)</h1>",
    "/frame-host": DASH.format(
        title="With an embedded frame",
        extra='<iframe id="inner" src="https://other.test/inner" style="position:fixed;top:80px;right:20px;width:260px;height:120px;background:#fff"></iframe>',
        **LIGHT,
    ),
    "/inner": "<!doctype html><title>inner</title><input id='field' placeholder='type here' autofocus>",
    "/slow": DASH.format(title="Slow page", extra='<img src="/slow-image" width="1" height="1">', **LIGHT),
    # A strict-CSP page with nothing inline of its own, so any violation logged is the extension's.
    "/csp": """<!doctype html><html><head><meta charset="utf-8"><title>Strict CSP</title>
<link rel="stylesheet" href="/site.css"></head><body><header><b>Fakehood</b></header>
<main><h1>$48,213.77</h1><p>Locked-down page: only same-origin styles and scripts are allowed.</p></main></body></html>""",
}

SITE_CSS = "body{margin:0;font:15px/1.5 system-ui,sans-serif} header{padding:20px 40px;border-bottom:1px solid #ddd} main{padding:28px 40px}"


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/redirect":
            self.send_response(302)
            self.send_header("Location", "/page2")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if path == "/slow-image":
            time.sleep(6)  # keeps the /slow page loading, so the note has to wait
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if path == "/site.css":
            data = SITE_CSS.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/css")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        body = PAGES.get(path)
        if body is None:
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        data = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        if path == "/csp":
            self.send_header("Content-Security-Policy", "default-src 'self'")
        self.end_headers()
        self.wfile.write(data)


def make_cert(work_dir):
    """Write a throwaway self-signed certificate into work_dir and return (cert, key).

    The name on it does not matter: the test browser is told to ignore certificate errors.
    """
    cert = os.path.join(work_dir, "cert.pem")
    key = os.path.join(work_dir, "key.pem")
    quiet = dict(check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        subprocess.run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", key], **quiet)
        subprocess.run(["openssl", "req", "-x509", "-new", "-key", key, "-days", "2", "-subj", "/CN=localhost", "-out", cert], **quiet)
    except FileNotFoundError:
        raise SystemExit("openssl was not found. The tests need it to make a throwaway certificate.")
    return cert, key


def start(work_dir):
    """Serve the stand-in pages over HTTPS on a free local port, and return that port."""
    cert, key = make_cert(work_dir)
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert, key)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd.server_address[1]
