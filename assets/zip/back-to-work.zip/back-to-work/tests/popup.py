"""Checks for the toolbar popup, the shared helpers and the jokes.

Run with `python3 tests/run.py popup`. It takes about fifteen seconds.
Set BTW_SHOTS to a folder to keep screenshots of the popup.
"""
import datetime
import json
import os
import shutil
import sys
import tempfile
import time

sys.dont_write_bytecode = True  # keep __pycache__ out of the extension folder
HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.dirname(HERE)  # the extension is the folder above tests/
sys.path.insert(0, HERE)
from cdp import Chrome, Tab  # noqa: E402

WORK = tempfile.mkdtemp(prefix="back-to-work-test-")  # browser profile; deleted at the end
SHOTS = os.environ.get("BTW_SHOTS")

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""), flush=True)


def shot(tab, name, height):
    if SHOTS:
        os.makedirs(SHOTS, exist_ok=True)
        tab.screenshot(os.path.join(SHOTS, name), clip={"x": 0, "y": 0, "width": 276, "height": height})


c = Chrome(os.path.join(WORK, "profile"), headless=True)
EXT_ID = c.send("Extensions.loadUnpacked", {"path": EXT})["id"]
URL = f"chrome-extension://{EXT_ID}/popup.html"
today = datetime.date.today()


def day(n):
    """The date n days ago, as the extension's YYYY-MM-DD key."""
    return (today - datetime.timedelta(days=n)).isoformat()


READ = """(() => ({
  count: document.getElementById('count').textContent,
  unit: document.getElementById('unit').textContent,
  verdict: document.getElementById('verdict').textContent,
  on: document.getElementById('enabled').checked,
  paused: document.body.classList.contains('paused'),
  resetDisabled: document.getElementById('reset').disabled,
  bars: [...document.querySelectorAll('#week li')].map(li => ({
    num: li.querySelector('.num').textContent, h: li.querySelector('.bar').getBoundingClientRect().height,
    day: li.querySelector('.day').textContent, today: li.classList.contains('today'), title: li.title })),
  width: document.body.getBoundingClientRect().width,
  height: document.documentElement.scrollHeight,
  overflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth,
}))()"""

try:
    print("\n== Popup: first run (nothing stored yet)")
    p = Tab(c, URL)
    p.cmd("Emulation.setDeviceMetricsOverride", {"width": 276, "height": 420, "deviceScaleFactor": 2, "mobile": False})
    time.sleep(0.5)
    s = p.js(READ)
    check("shows 0 with the empty-state line", s["count"] == "0" and s["verdict"] == "Nothing yet. Suspiciously disciplined.", json.dumps(s)[:200])
    check("switch starts on", s["on"] is True and s["paused"] is False)
    check("reset is disabled when there is nothing to reset", s["resetDisabled"] is True)
    check("seven day columns, today last and highlighted", len(s["bars"]) == 7 and s["bars"][-1]["today"] and not any(b["today"] for b in s["bars"][:-1]))
    check("popup is 276px wide with no sideways scroll", abs(s["width"] - 276) < 0.5 and not s["overflowX"], f"{s['width']} {s['overflowX']}")
    check("nothing is written just by opening the popup", p.js("chrome.storage.local.get(null)") == {}, str(p.js("chrome.storage.local.get(null)")))
    shot(p, "10-popup-empty.png", s["height"])

    print("\n== Popup: a week of history")
    seed = {day(0): 7, day(1): 12, day(2): 3, day(4): 21, day(5): 1, day(6): 9, day(7): 30, day(20): 4}
    p.js(f"chrome.storage.local.set({{counts: {json.dumps(seed)}}})"); time.sleep(0.4)
    s = p.js(READ)
    check("updates live when the tally changes", s["count"] == "7" and s["unit"] == "Robinhood checks today", json.dumps(s)[:160])
    check("verdict matches the tier for 7", s["verdict"] == "Getting a little clingy.", s["verdict"])
    nums = [b["num"] for b in s["bars"]]
    check("bars show the last seven days, oldest first", nums == ["9", "1", "21", "", "3", "12", "7"], str(nums))
    hs = [b["h"] for b in s["bars"]]
    check("tallest bar is the biggest day; empty day is a 2px stub", max(hs) == hs[2] and abs(hs[2] - 44) < 0.5 and abs(hs[3] - 2) < 0.5, str(hs))
    check("bar heights are in proportion", abs(hs[5] / hs[2] - 12 / 21) < 0.03, str(hs))
    check("hover text names the day and count", s["bars"][-1]["title"].endswith(": 7 checks") and s["bars"][1]["title"].endswith(": 1 check"), s["bars"][-1]["title"] + " | " + s["bars"][1]["title"])
    check("reset is enabled now", s["resetDisabled"] is False)
    shot(p, "11-popup-week-light.png", s["height"])
    p.cmd("Emulation.setEmulatedMedia", {"features": [{"name": "prefers-color-scheme", "value": "dark"}]})
    time.sleep(0.3)
    shot(p, "12-popup-week-dark.png", s["height"])

    print("\n== Popup: the switch and reset")
    p.js("document.getElementById('enabled').click(); 1"); time.sleep(0.4)
    s = p.js(READ)
    st = p.js("chrome.storage.local.get(null)")
    check("switching off is saved", st.get("enabled") is False, str(st))
    check("popup shows the paused state", s["paused"] and s["verdict"] == "Paused. Not counting, no reminders." and s["on"] is False, json.dumps(s)[:200])
    shot(p, "13-popup-paused-dark.png", s["height"])
    p2 = Tab(c, URL); time.sleep(0.5)
    check("the off state survives closing and reopening the popup", p2.js(READ)["on"] is False)
    p2.close()
    p.js("document.getElementById('enabled').click(); 1"); time.sleep(0.4)
    check("switching back on is saved", p.js("chrome.storage.local.get(null)").get("enabled") is True and p.js(READ)["paused"] is False)
    p.js("document.getElementById('reset').click(); 1"); time.sleep(0.4)
    s = p.js(READ)
    st = p.js("chrome.storage.local.get(null)")
    check("reset clears today only", s["count"] == "0" and day(0) not in st["counts"] and st["counts"].get(day(1)) == 12, str(st["counts"]))
    p.js(f"chrome.storage.local.set({{counts: {{'{day(0)}': 1}}}})"); time.sleep(0.4)
    s = p.js(READ)
    check("singular wording at 1", s["unit"] == "Robinhood check today" and s["verdict"] == "Perfectly reasonable.", json.dumps(s)[:160])

    print("\n== Shared helpers and jokes")
    r = p.js("""(() => {
      const out = {};
      out.dayKey = BTW.dayKey(new Date(2026, 0, 5, 23, 59));
      out.dayKeyMidnight = BTW.dayKey(new Date(2026, 11, 31, 0, 0, 1));
      // across the US daylight-saving changes (Mar 8 and Nov 1, 2026) and a month/year boundary
      out.springDays = BTW.lastDays(7, new Date(2026, 2, 10, 12)).map(d => BTW.dayKey(d));
      out.fallDays = BTW.lastDays(7, new Date(2026, 10, 3, 0, 30)).map(d => BTW.dayKey(d));
      out.newYear = BTW.lastDays(3, new Date(2027, 0, 1, 9)).map(d => BTW.dayKey(d));
      const many = {};
      for (let i = 0; i < 90; i++) { const d = new Date(2026, 0, 1 + i); many[BTW.dayKey(d)] = i + 1; }
      many['junk'] = 5; many['2026-13-99x'] = 2; many['2026-02-02'] = 0; many['2026-02-03'] = 'x';
      const kept = BTW.prune(many);
      out.keptCount = Object.keys(kept).length;
      out.keptFirst = Object.keys(kept).sort()[0];
      out.keptLast = Object.keys(kept).sort().pop();
      out.pruneEmpty = JSON.stringify([BTW.prune(undefined), BTW.prune(null), BTW.prune({})]);
      out.tiers = [0, 1, 2, 4, 5, 9, 10, 19, 20, 500].map(n => (BTW.tierFor(n) || {from: null}).from);
      out.emoji = [1, 2, 5, 10, 20].map(n => BTW.pickLine(n, '').emoji);
      // never the same line twice running, across 400 draws per tier
      out.repeats = 0; out.badFill = 0; out.tooLong = [];
      for (const n of [1, 3, 7, 14, 33]) {
        let last = '';
        for (let i = 0; i < 400; i++) {
          const p = BTW.pickLine(n, last);
          if (p.line === last) out.repeats++;
          if (!p.line || p.line.includes('{n}') || p.line.includes('undefined')) out.badFill++;
          last = p.line;
        }
      }
      out.fill = BTW.tiers.flatMap(t => t.lines).filter(l => l.includes('{n}')).length;
      out.filled = (() => { for (let i = 0; i < 300; i++) { const p = BTW.pickLine(14, ''); if (p.line.startsWith('14 looks')) return p.line; } return null; })();
      for (const t of BTW.tiers) for (const l of t.lines) if (l.length > 60) out.tooLong.push(l);
      out.lineCount = BTW.tiers.reduce((a, t) => a + t.lines.length, 0);
      out.dupes = (() => { const all = BTW.tiers.flatMap(t => t.lines); return all.length - new Set(all).size; })();
      out.verdicts = [0, 1, 3, 6, 12, 25].map(n => BTW.verdict(n));
      out.frozen = Object.isFrozen(BTW.DEFAULTS);
      return out;
    })()""")
    check("day key is the local date, zero-padded", r["dayKey"] == "2026-01-05" and r["dayKeyMidnight"] == "2026-12-31", f"{r['dayKey']} {r['dayKeyMidnight']}")
    check("seven-day window is right across the spring clock change", r["springDays"] == ["2026-03-04", "2026-03-05", "2026-03-06", "2026-03-07", "2026-03-08", "2026-03-09", "2026-03-10"], str(r["springDays"]))
    check("seven-day window is right across the autumn clock change", r["fallDays"] == ["2026-10-28", "2026-10-29", "2026-10-30", "2026-10-31", "2026-11-01", "2026-11-02", "2026-11-03"], str(r["fallDays"]))
    check("window crosses a year boundary correctly", r["newYear"] == ["2026-12-30", "2026-12-31", "2027-01-01"], str(r["newYear"]))
    check("history is trimmed to the newest 60 counted days and junk entries are dropped", r["keptCount"] == 60 and r["keptLast"] == "2026-03-31" and r["keptFirst"] == "2026-01-29", f"{r['keptCount']} {r['keptFirst']}..{r['keptLast']}")
    check("prune copes with missing data", r["pruneEmpty"] == "[{},{},{}]", r["pruneEmpty"])
    check("tiers switch at 1, 2, 5, 10 and 20", r["tiers"] == [None, 1, 2, 2, 5, 5, 10, 10, 20, 20], str(r["tiers"]))
    check("each tier has its emoji", r["emoji"] == ["\U0001F440", "\U0001F440", "\U0001F643", "\U0001F62C", "\U0001F6A8"], str(r["emoji"]))
    check("never the same joke twice in a row (2000 draws)", r["repeats"] == 0, str(r["repeats"]))
    check("every joke is filled in properly", r["badFill"] == 0 and r["filled"] == "14 looks today. Even the ticker thinks that's a lot.", f"{r['badFill']} {r['filled']}")
    check("every joke fits on one row (60 characters or fewer)", not r["tooLong"], str(r["tooLong"]))
    check(f"{r['lineCount']} jokes, no duplicates", r["lineCount"] >= 30 and r["dupes"] == 0, f"{r['lineCount']} {r['dupes']}")
    check("verdict lines by tier", r["verdicts"] == ["Nothing yet. Suspiciously disciplined.", "Perfectly reasonable.", "A healthy curiosity.", "Getting a little clingy.", "The stocks feel watched.", "This is a lifestyle now."], str(r["verdicts"]))

    errs = [ev for ev in c.event_log if ev.get("method") == "Runtime.exceptionThrown" or (ev.get("method") == "Log.entryAdded" and ev["params"]["entry"]["level"] == "error")]
    check("no errors in the popup", not errs, json.dumps(errs)[:400])

    print("\n== Chrome's own view of the folder")
    info = None
    try:
        x = Tab(c, "chrome://extensions/")
        time.sleep(1.0)
        info = x.js("""(async () => {
          const api = chrome.developerPrivate;
          if (!api || !api.getExtensionInfo) return null;
          const info = await new Promise((resolve, reject) => {
            const p = api.getExtensionInfo('%s', resolve);
            if (p && p.then) p.then(resolve, reject);
          });
          return {
            warnings: info.installWarnings || [],
            manifestErrors: info.manifestErrors || [],
            hosts: ((info.permissions.runtimeHostPermissions || {}).hosts || []).map(h => h.host),
            prompts: (info.permissions.simplePermissions || []).map(p => p.message),
          };
        })()""" % EXT_ID)
    except Exception as e:  # noqa: BLE001
        print("   (could not read chrome://extensions:", str(e)[:120], ")")
    if info is None:
        print("  SKIP  this Chrome does not let the test read its extensions page")
    else:
        check("Chrome loads the folder with no warnings or manifest errors",
              not info["warnings"] and not info["manifestErrors"], json.dumps(info)[:300])
        check("site access is https://robinhood.com/* only, and no permission needs a warning",
              info["hosts"] == ["https://robinhood.com/*"] and not info["prompts"], json.dumps(info)[:300])
finally:
    c.close()
    shutil.rmtree(WORK, ignore_errors=True)

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
for name, _ok, detail in failed:
    print("  FAILED:", name, "--", detail)
sys.exit(1 if failed else 0)
