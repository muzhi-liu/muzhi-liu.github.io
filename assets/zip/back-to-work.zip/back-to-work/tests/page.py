"""End-to-end checks for the page script, against a local stand-in for robinhood.com.

Run with `python3 tests/run.py page`. It takes about four minutes: most of that is
waiting out the five seconds that must pass before a return to the tab counts again.
Set BTW_SHOTS to a folder to keep screenshots of the note.
"""
import datetime
import json
import os
import shutil
import sys
import tempfile
import time

sys.dont_write_bytecode = True  # keep __pycache__ out of the extension folder
HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.dirname(HERE)  # the extension is the folder above tests/
sys.path.insert(0, HERE)
from cdp import Chrome, Tab  # noqa: E402
import server  # noqa: E402

WORK = tempfile.mkdtemp(prefix="back-to-work-test-")  # browser profile and certificate; deleted at the end
SHOTS = os.environ.get("BTW_SHOTS")

GRACE = 5.0
AWAY = GRACE + 0.7  # comfortably longer than the grace window
SETTLE = 1.4  # dwell (0.6s) + storage round trip + fade-in

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""), flush=True)


def section(title):
    print(f"\n== {title}", flush=True)


worst_overrun = 0.0


def wait(seconds):
    """Sleep, noting how late the wake-up was: a held-up test is the usual cause of a timing failure."""
    global worst_overrun
    start = time.monotonic()
    time.sleep(seconds)
    worst_overrun = max(worst_overrun, time.monotonic() - start - seconds)


def shot(tab, name):
    if SHOTS:
        os.makedirs(SHOTS, exist_ok=True)
        tab.screenshot(os.path.join(SHOTS, name))


TOAST_JS = """(() => {
  const h = document.querySelector('[data-back-to-work]');
  if (!h) return null;
  const r = chrome.dom.openOrClosedShadowRoot(h);
  const t = r.querySelector('.toast');
  const cs = getComputedStyle(t);
  const b = t.getBoundingClientRect();
  return {
    cls: t.className, title: r.querySelector('.title').textContent,
    line: r.querySelector('.line').textContent, emoji: r.querySelector('.emoji').textContent,
    opacity: cs.opacity, bg: cs.backgroundColor, radius: cs.borderTopLeftRadius,
    hostPE: getComputedStyle(h).pointerEvents, hostPos: getComputedStyle(h).position,
    rect: {x: b.x, y: b.y, w: b.width, h: b.height}, vw: document.documentElement.clientWidth, vh: innerHeight,
    hosts: document.querySelectorAll('[data-back-to-work]').length,
  };
})()"""

# Added to the Robinhood tab's pages by the test (it is not part of the extension). It keeps a
# timeline, in milliseconds since the page began, of when the note is added and removed and of
# focus and visibility changes, so timing checks use the page's own clock, not the test's.
WATCH_JS = """(() => {
  const log = (window.__btwLog = []);
  const mark = (kind) => log.push({kind, at: Math.round(performance.now()), ready: document.readyState,
                                   focus: document.hasFocus(), vis: document.visibilityState});
  for (const kind of ['blur', 'focus', 'pageshow', 'pagehide']) window.addEventListener(kind, () => mark(kind), true);
  document.addEventListener('visibilitychange', () => mark('visibility'), true);
  new MutationObserver((records) => {
    for (const r of records) {
      for (const n of r.addedNodes) if (n.nodeType === 1 && n.hasAttribute('data-back-to-work')) mark('note-added');
      for (const n of r.removedNodes) if (n.nodeType === 1 && n.hasAttribute('data-back-to-work')) mark('note-removed');
    }
  }).observe(document, {childList: true, subtree: true});
})();"""

PORT = server.start(WORK)
c = Chrome(os.path.join(WORK, "profile"), headless=True, args=[
    # robinhood.com (and other.test, used for an embedded frame) resolve to the stand-in server
    f"--host-resolver-rules=MAP robinhood.com 127.0.0.1:{PORT}, MAP other.test 127.0.0.1:{PORT}",
    "--ignore-certificate-errors",
])
EXT_ID = c.send("Extensions.loadUnpacked", {"path": EXT})["id"]
TODAY = datetime.date.today().isoformat()

# helper tabs first, so that creating them later does not steal the foreground
other = Tab(c, "data:text/html,<title>elsewhere</title><h1>Some other tab</h1>")
ext = Tab(c, f"chrome-extension://{EXT_ID}/popup.html")


def store():
    return ext.js("chrome.storage.local.get(null)")


def count():
    return store().get("counts", {}).get(TODAY, 0)


def toast(tab):
    ctx = tab.ext_context()
    return tab.js(TOAST_JS, context=ctx) if ctx else None


def has_host(tab):
    return tab.js("!!document.querySelector('[data-back-to-work]')")


def timeline(tab):
    """What WATCH_JS has recorded in the tab's current page."""
    return tab.js("window.__btwLog || []")


def when(log, kind, **match):
    """Milliseconds into the page at which `kind` first happened, or None if it never did."""
    for entry in log:
        if entry["kind"] == kind and all(entry.get(key) == value for key, value in match.items()):
            return entry["at"]
    return None


def errors(tab):
    out = []
    for ev in list(c.event_log):
        if ev.get("sessionId") != tab.session:
            continue
        if ev["method"] == "Runtime.exceptionThrown":
            out.append(ev["params"]["exceptionDetails"].get("text", "") + " " +
                       json.dumps(ev["params"]["exceptionDetails"].get("exception", {}))[:200])
        if ev["method"] == "Log.entryAdded" and ev["params"]["entry"]["level"] == "error":
            url = ev["params"]["entry"].get("url", "")
            if "favicon" in url or "slow-image" in url:
                continue
            out.append(ev["params"]["entry"]["text"] + " " + url)
    return out


def away_then_back(tab, seconds=AWAY):
    other.activate()
    wait(seconds)
    tab.activate()
    wait(SETTLE)


try:
    # ------------------------------------------------------------------
    section("1. Opening Robinhood counts once and shows the note")
    rh = Tab(c)
    rh.cmd("Page.addScriptToEvaluateOnNewDocument", {"source": WATCH_JS})
    rh.goto("https://robinhood.com/")
    wait(SETTLE)
    t = toast(rh)
    check("count is 1 after opening the tab", count() == 1, f"count={count()}")
    check("note is on the page", t is not None)
    if t:
        check("note title reads 'Check #1 today'", t["title"] == "Check #1 today", t["title"])
        check("note has a joke line", len(t["line"]) > 8, t["line"])
        check("note is fully faded in", t["cls"] == "toast in" and float(t["opacity"]) > 0.98, f"{t['cls']} {t['opacity']}")
        check("background is see-through (alpha 0.66)", t["bg"].replace(" ", "") == "rgba(20,23,28,0.66)", t["bg"])
        check("note ignores the mouse (pointer-events: none)", t["hostPE"] == "none", t["hostPE"])
        check("note is pinned to the window (position: fixed)", t["hostPos"] == "fixed", t["hostPos"])
        cx, cy = t["rect"]["x"] + t["rect"]["w"] / 2, t["rect"]["y"] + t["rect"]["h"] / 2
        under = rh.js(f"(() => {{ const e = document.elementFromPoint({cx}, {cy}); return e ? e.tagName + (e.hasAttribute('data-back-to-work') ? ':NOTE' : '') : null; }})()")
        check("a click at the note's centre lands on the page underneath", under is not None and "NOTE" not in under, str(under))
        check("note sits at the bottom centre, inside the window",
              abs((t["rect"]["x"] + t["rect"]["w"] / 2) - t["vw"] / 2) < 2 and t["rect"]["y"] + t["rect"]["h"] <= t["vh"] - 20 and t["rect"]["y"] > t["vh"] * 0.6,
              json.dumps(t["rect"]))
        check("note is compact: one row of text (under 500px wide, under 62px tall)", t["rect"]["w"] <= 500 and t["rect"]["h"] <= 62, json.dumps(t["rect"]))
    shot(rh, "01-first-check-light.png")
    st = store()
    check("only the expected keys are stored", set(st.keys()) <= {"counts", "lastActiveAt", "lastLine", "enabled"}, str(list(st.keys())))
    wait(5.2)  # long enough for the note to have come and gone
    log = timeline(rh)
    added, removed = when(log, "note-added"), when(log, "note-removed")
    check("note appears within two seconds of opening the tab", added is not None and added <= 2000, json.dumps(log)[:500])
    check("note stays up for about five seconds (between 5.2 and 5.9)",
          added is not None and removed is not None and 5200 <= removed - added <= 5900, json.dumps(log)[:500])
    check("nothing is left in the page afterwards", not has_host(rh))

    # ------------------------------------------------------------------
    section("2. Staying on Robinhood: reloads, in-site navigation and route changes are not new checks")
    rh.cmd("Page.reload"); wait(SETTLE + 0.4)
    check("reload after a long stay does not count", count() == 1 and not has_host(rh), f"count={count()}")
    wait(AWAY)
    rh.js("location.href = '/page2'; 1", await_promise=False); wait(SETTLE + 0.4)
    check("full navigation to another Robinhood page does not count", count() == 1 and not has_host(rh), f"count={count()} url={rh.js('location.pathname')}")
    wait(AWAY)
    rh.goto("https://robinhood.com/redirect", wait=SETTLE + 0.4)
    check("server redirect within Robinhood does not count", count() == 1 and rh.js("location.pathname") == "/page2", f"count={count()}")
    rh.goto("https://robinhood.com/", wait=SETTLE + 0.4)
    wait(AWAY)
    rh.js("document.getElementById('spa').click(); 1"); wait(SETTLE)
    check("single-page route change does not count", count() == 1 and rh.js("location.pathname") == "/stocks/AAPL", f"count={count()}")

    # ------------------------------------------------------------------
    section("3. Switching tabs")
    away_then_back(rh, 1.5)
    check("away for 1.5s and back: same check, no note", count() == 1 and not has_host(rh), f"count={count()}")
    wait(1.0)
    away_then_back(rh)
    t = toast(rh)
    check("away for longer than 5s and back: count goes to 2", count() == 2, f"count={count()}")
    check("note reads 'Check #2 today'", bool(t) and t["title"] == "Check #2 today", str(t and t["title"]))
    first_line = t["line"] if t else ""
    check("the joke shown is remembered", store().get("lastLine") == first_line, store().get("lastLine"))
    other.activate(); wait(0.3)
    check("leaving while the note is up removes it immediately", not has_host(rh))
    wait(AWAY)
    rh.activate(); wait(0.25); other.activate(); wait(1.0)
    check("flicking past the tab for a quarter second does not count", count() == 2, f"count={count()}")
    rh.activate(); wait(SETTLE)
    t = toast(rh)
    check("...and the real visit right after still counts (3)", count() == 3 and bool(t) and t["title"] == "Check #3 today", f"count={count()}")
    check("a different joke than last time", bool(t) and t["line"] != first_line, f"{first_line!r} vs {t and t['line']!r}")
    check("only ever one note in the page", bool(t) and t["hosts"] == 1, str(t and t["hosts"]))

    # ------------------------------------------------------------------
    section("4. Support and marketing pages (robinhood.com/us/...) are left alone")
    other.activate(); wait(AWAY)
    rh.goto("https://robinhood.com/us/en/support", wait=0.5)
    rh.activate(); wait(SETTLE)
    check("no script runs on the excluded page", rh.ext_context() is None and not has_host(rh))
    check("excluded page does not count", count() == 3, f"count={count()}")
    wait(AWAY)
    rh.goto("https://robinhood.com/", wait=SETTLE + 0.4)
    check("going from a support page to the account page counts (4)", count() == 4, f"count={count()}")

    # ------------------------------------------------------------------
    section("5. The on/off switch")
    wait(0.5)
    check("note is up before pausing", has_host(rh))
    ext.js("chrome.storage.local.set({enabled: false})"); wait(0.4)
    check("pausing removes a note that is showing", not has_host(rh))
    before = store()
    away_then_back(rh)
    away_then_back(rh)
    after = store()
    check("paused: coming back does not count", count() == 4, f"count={count()}")
    check("paused: no note", not has_host(rh))
    check("paused: nothing at all is written", before == after, f"{before} vs {after}")
    ext.js("chrome.storage.local.set({enabled: true})"); wait(SETTLE)
    check("switching back on does not nag straight away", count() == 4 and not has_host(rh), f"count={count()}")
    away_then_back(rh)
    check("switched on again: the next visit counts (5)", count() == 5 and has_host(rh), f"count={count()}")
    t = toast(rh)
    check("tier changes at 5 (upside-down face)", bool(t) and t["emoji"] == "\U0001F643", str(t and t["emoji"]))

    # ------------------------------------------------------------------
    section("6. Coming back from another app (window focus only; the tab never hides)")
    ctx = rh.ext_context()
    BLUR = "window.__hf = window.__hf || Document.prototype.hasFocus; Document.prototype.hasFocus = () => false; window.dispatchEvent(new Event('blur')); 1"
    FOCUS = "Document.prototype.hasFocus = window.__hf; window.dispatchEvent(new Event('focus')); 1"
    wait(1.0)
    rh.js(BLUR, context=ctx); wait(0.3)
    check("losing window focus removes the note", not has_host(rh))
    wait(1.5)
    rh.js(FOCUS, context=ctx); wait(SETTLE)
    check("brief focus loss (under 5s) is the same check", count() == 5 and not has_host(rh), f"count={count()}")
    rh.js(BLUR, context=ctx); wait(AWAY)
    rh.js(FOCUS, context=ctx); wait(SETTLE)
    check("focus regained after more than 5s counts (6)", count() == 6 and has_host(rh), f"count={count()}")

    # ------------------------------------------------------------------
    section("7. Opening and closing the extension's own popup is not a check")
    wait(6.0)  # let the note finish
    popup = Tab(c, f"chrome-extension://{EXT_ID}/popup.html", background=True)
    found = popup.js("""(async () => {
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        const port = chrome.tabs.connect(tab.id, {name: 'btw-popup'});
        let closed = false;
        port.onDisconnect.addListener(() => { closed = true; void chrome.runtime.lastError; });
        await new Promise(r => setTimeout(r, 300));
        if (!closed) { window.__port = port; return {id: tab.id, urlVisible: 'url' in tab}; }
      }
      return null;
    })()""")
    check("popup reaches the Robinhood tab's script", found is not None, str(found))
    check("popup cannot see tab addresses (no tabs permission)", found is not None and found["urlVisible"] is False, str(found))
    rh.js(BLUR, context=ctx)  # the popup takes focus
    wait(AWAY)  # ...and stays open a while
    stamp_before = store().get("lastActiveAt")
    popup.close(); wait(0.3)  # closing the popup drops the port
    stamp_after = store().get("lastActiveAt")
    check("closing the popup is noted", stamp_after > stamp_before, f"{stamp_before} -> {stamp_after}")
    rh.js(FOCUS, context=ctx); wait(SETTLE)
    check("focus coming back from the popup does not count", count() == 6 and not has_host(rh), f"count={count()}")

    # ------------------------------------------------------------------
    section("8. Clicking into an embedded frame and back is not a check")
    rh.goto("https://robinhood.com/frame-host", wait=1.5)
    rh.js("window.__blurs = 0; window.__focuses = 0; addEventListener('blur', () => window.__blurs++); addEventListener('focus', () => window.__focuses++); 1")
    box = rh.js("(() => { const r = document.getElementById('inner').getBoundingClientRect(); return {x: r.x + 40, y: r.y + 14}; })()")
    for typ in ("mousePressed", "mouseReleased"):
        rh.cmd("Input.dispatchMouseEvent", {"type": typ, "x": box["x"], "y": box["y"], "button": "left", "clickCount": 1})
    wait(AWAY)
    blurs = rh.js("window.__blurs")
    still = rh.js("document.hasFocus()")
    for typ in ("mousePressed", "mouseReleased"):
        rh.cmd("Input.dispatchMouseEvent", {"type": typ, "x": 300, "y": 300, "button": "left", "clickCount": 1})
    wait(SETTLE)
    focuses = rh.js("window.__focuses")
    check("(the frame really did take focus from the page)", blurs >= 1 and still is True and focuses >= 1, f"blurs={blurs} hasFocus={still} focuses={focuses}")
    check("time spent inside an embedded frame is not a new check", count() == 6 and not has_host(rh), f"count={count()}")

    # ------------------------------------------------------------------
    section("9. Back/forward, and a second Robinhood tab")
    rh.goto("https://robinhood.com/", wait=1.5)
    rh.js("window.__persisted = null; addEventListener('pageshow', e => window.__persisted = e.persisted); 1")
    wait(AWAY)
    rh.js("location.href = '/page2'; 1", await_promise=False); wait(AWAY)
    rh.js("history.back(); 1", await_promise=False); wait(SETTLE + 0.5)
    persisted = rh.js("window.__persisted")
    check("Back button after a long stay does not count" + (" (restored from the back/forward cache)" if persisted else ""),
          count() == 6 and rh.js("location.pathname") == "/" and not has_host(rh), f"count={count()} persisted={persisted}")
    wait(AWAY)
    rh2 = Tab(c, "https://robinhood.com/page2"); wait(SETTLE)
    check("opening a second Robinhood tab straight from the first does not count", count() == 6 and not has_host(rh2), f"count={count()}")
    wait(AWAY)
    rh.activate(); wait(SETTLE)
    check("hopping between two Robinhood tabs does not count", count() == 6, f"count={count()}")
    rh2.close(); wait(0.5)

    # ------------------------------------------------------------------
    section("10. Slow pages, strict pages, narrow windows, dark pages")
    other.activate(); wait(AWAY)
    rh.cmd("Page.navigate", {"url": "https://robinhood.com/slow"}); wait(0.6)
    rh.activate(); wait(SETTLE)
    check("count goes up at once on a slow page (7)", count() == 7, f"count={count()} ready={rh.js('document.readyState')}")
    check("...but the note waits while the page is still loading", rh.js("document.readyState") != "complete" and not has_host(rh), rh.js("document.readyState"))
    wait(3.2)  # until after the note's three-second limit on waiting
    log = timeline(rh)
    shown, added = when(log, "visibility", vis="visible"), when(log, "note-added")
    still_loading = any(e["kind"] == "note-added" and e["ready"] != "complete" for e in log)
    check("...and appears anyway about three and a half seconds after you arrive, before the page has finished",
          shown is not None and added is not None and 3300 <= added - shown <= 4300 and still_loading, json.dumps(log)[:500])

    other.activate(); wait(AWAY)
    rh.cmd("Page.navigate", {"url": "https://robinhood.com/csp"}); wait(0.8)
    rh.activate(); wait(SETTLE)
    t = toast(rh)
    check("strict Content-Security-Policy page: note still styled (8)",
          count() == 8 and bool(t) and t["bg"].replace(" ", "") == "rgba(20,23,28,0.66)" and t["radius"] == "16px", str(t and (t["bg"], t["radius"])))
    csp_errs = [e for e in errors(rh) if "/csp" in e or "Content Security Policy" in e]
    check("strict CSP page: the note causes no policy violations", not csp_errs, " | ".join(csp_errs)[:300])
    blocked = rh.js("(() => { const s = document.createElement('style'); s.textContent = 'h1{letter-spacing:9px}'; document.head.append(s); return getComputedStyle(document.querySelector('h1')).letterSpacing; })()")
    check("(the page's policy really does block inline styles)", blocked != "9px", blocked)
    n_csp_probe = len(errors(rh))

    other.activate(); wait(AWAY)
    rh.cmd("Emulation.setDeviceMetricsOverride", {"width": 360, "height": 700, "deviceScaleFactor": 2, "mobile": False})
    rh.cmd("Page.navigate", {"url": "https://robinhood.com/"}); wait(0.8)
    rh.activate(); wait(SETTLE)
    t = toast(rh)
    check("narrow window (360px): note fits with margins (9)",
          count() == 9 and bool(t) and t["rect"]["x"] >= 15.5 and t["rect"]["x"] + t["rect"]["w"] <= t["vw"] - 15.5, str(t and (t["rect"], t["vw"])))
    shot(rh, "02-narrow.png")
    rh.cmd("Emulation.clearDeviceMetricsOverride")

    other.activate(); wait(AWAY)
    rh.cmd("Page.navigate", {"url": "https://robinhood.com/dark"}); wait(0.8)
    rh.activate(); wait(SETTLE)
    t = toast(rh)
    check("tenth check moves to the next tier (grimace)", count() == 10 and bool(t) and t["emoji"] == "\U0001F62C", f"count={count()} {t and t['emoji']}")
    shot(rh, "03-tenth-check-dark.png")

    # ------------------------------------------------------------------
    section("11. No errors logged on any page")
    errs = [e for e in errors(rh) + errors(other) if "h1{letter-spacing" not in e and "Applying inline style" not in e]
    check("no exceptions or console errors from the extension", not errs, " | ".join(errs)[:500])

    # ------------------------------------------------------------------
    section("12. Switching the whole extension off while a tab is open")
    wait(6.0)
    away_then_back(rh)
    check("a note is showing (11)", count() == 11 and has_host(rh), f"count={count()}")
    try:
        c.send("Extensions.uninstall", {"id": EXT_ID})
        removed = True
    except Exception as e:  # noqa: BLE001
        removed = False
        print("   (Extensions.uninstall unavailable:", str(e)[:120], ")")
    if removed:
        wait(0.5)
        n_before = len(errors(rh))
        other.activate(); wait(0.4)
        check("after removal, leaving the tab still clears the note", not has_host(rh))
        rh.activate(); wait(SETTLE)
        other.activate(); wait(0.3); rh.activate(); wait(SETTLE)
        check("after removal, no new note appears", not has_host(rh))
        new_errs = errors(rh)[n_before:]
        check("after removal, the orphaned script raises no errors", not new_errs, " | ".join(new_errs)[:400])
finally:
    c.close()
    shutil.rmtree(WORK, ignore_errors=True)

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
print(f"(longest overrun of a wait in the test itself: {worst_overrun * 1000:.0f} ms)")
for name, _ok, detail in failed:
    print("  FAILED:", name, "--", detail)
sys.exit(1 if failed else 0)
