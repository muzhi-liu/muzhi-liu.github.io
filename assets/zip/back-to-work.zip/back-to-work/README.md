# Back to Work

A small Chrome extension that counts how many times a day you check Robinhood
and tells you, briefly and politely, to go back to work.

Each time a Robinhood tab comes in front of you, the day's tally goes up by
one and a see-through note slides in at the bottom of the page:

> **CHECK #7 TODAY**
> Staring doesn't make it go up. We checked.

The note fades after five seconds. Clicks pass straight through it, so it can
never get between you and a button. The jokes get less patient as the count
climbs.

## Install

It is not on the Chrome Web Store, so you load it from a folder.

1. Get the folder, if you are reading this on GitHub: **Code**, then
   **Download ZIP**, and unzip it. Or clone it:

   ```
   git clone https://github.com/muzhi-liu/back-to-work.git
   ```

2. Open `chrome://extensions` in Chrome (Edge, Brave and Arc work the same way).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and choose the folder, the one with
   `manifest.json` in it.
5. Reload any Robinhood tab that was already open. Chrome only adds the
   script to pages loaded after the extension is installed.

Keep the folder where it is: Chrome runs the extension from it.

Leave Developer mode on as well. With it off, Chrome's extensions page shows a
Safety Check notice saying it cannot verify where the extension comes from,
and recommends removing it. Chrome says that about extensions that were not
installed from the Chrome Web Store.

## What counts as a check

- Switching to a Robinhood tab, opening Robinhood, or coming back to the
  browser with Robinhood showing.
- You have to stay for more than half a second, so flicking past the tab on
  the way to another one is free.
- Coming back within five seconds of leaving is the same check.
- Reloading, clicking around inside Robinhood and moving between two Robinhood
  tabs are not new checks.
- Only the account site (`robinhood.com`) counts. Help and marketing pages
  under `robinhood.com/us/` are left alone.

The toolbar button shows today's count, the last seven days and a
**Reset today** button.

## Turning it off

- **Pause:** click the toolbar button and flip the switch. While it is off the
  extension counts nothing, shows nothing and writes nothing. Flip it back
  whenever you like; your history is kept.
- **Disable or remove:** `chrome://extensions`, then the toggle or **Remove**
  on the Back to Work card. Nothing is left behind in the page or in the
  browser. Removing it deletes the tally.

## What it can and cannot do

- It runs only on `https://robinhood.com/*`, and the one permission it
  requests is `storage`, to keep the tally in this browser.
- Chrome's details page says the extension "can read and change your data on
  sites", and lists `https://robinhood.com/*` as the only one. That is
  Chrome's standard wording for any extension that adds something to a page,
  and drawing the note needs it. The code itself does not read the page, your
  balances or anything you type. It does not touch the page's cookies or
  storage, and it makes no network requests.
- The whole thing is a few hundred lines of plain JavaScript in this folder,
  with no build step and no third-party code, so you can check all of that
  yourself.
- It keeps four things in `chrome.storage.local`: the on/off switch, a count
  per day (the latest 60 days), when you were last on Robinhood, and the last
  joke shown.

## Changing things

- The jokes and the counts at which they change tone are in `messages.js`.
- The timings are at the top of `content.js`: how long the note stays
  (`SHOW_MS`), how soon a return counts again (`GRACE_MS`), and how long you
  must stay for a visit to count (`DWELL_MS`).
- Position, size and transparency are in the `CSS` block in `content.js`
  (`bottom`, `max-width` and the `background` alpha).

After editing, press the reload arrow on the extension's card in
`chrome://extensions`, then reload your Robinhood tab.

## Tests

```
python3 tests/run.py
```

That runs about a hundred end-to-end checks in roughly four minutes. Most of
the time goes on waiting out the five seconds that must pass before a return
to the tab counts again. `python3 tests/run.py popup` runs only the quick
half.

The tests need Python 3, Google Chrome and `openssl`, and no packages. They
have only been run on macOS. If Chrome is installed somewhere unusual, set
`CHROME` to the path of its binary.

They start their own headless Chrome with a throwaway profile and tell it to
find `robinhood.com` at a stand-in page served from your own machine. Your
browser profile is not used and nothing is sent to the real site. Chrome never
loads anything in `tests/` as part of the extension.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | Where the extension runs and the one permission it asks for |
| `content.js` | Runs on Robinhood pages: decides what counts as a check and draws the note |
| `messages.js` | The jokes, and the counts at which the tone changes |
| `shared.js` | Date and tally helpers used by the page script and the popup |
| `popup.html`, `popup.css`, `popup.js` | The toolbar popup: today's count, the past week, the switch |
| `icons/` | The toolbar and extensions-page icons |
| `tests/` | The checks, a small Chrome driver and the stand-in site they run against |
| `LICENSE` | MIT |

## License

MIT. See [LICENSE](LICENSE).

Built with [Claude Code](https://claude.com/claude-code).

---

Not affiliated with or endorsed by Robinhood Markets, Inc. The jokes are
jokes, not financial advice.
