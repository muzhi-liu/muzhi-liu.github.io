# Back to Work

A small Chrome extension that counts how many times a day you check Robinhood
and tells you, briefly and politely, to go back to work.

Each time a Robinhood tab comes in front of you, the day's tally goes up by
one and a see-through note slides in at the bottom of the page:

> **CHECK #7 TODAY**
> Staring doesn't make it go up. We checked.

The note fades after five seconds. Clicks pass straight through it, so it can
never get between you and a button. The jokes get less patient as the count
climbs.

## Install

1. Open `chrome://extensions` in Chrome (Edge, Brave and Arc work the same way).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose this folder.
4. Reload any Robinhood tab that was already open. Chrome only adds the
   script to pages loaded after the extension is installed.

Keep the folder where it is: Chrome runs the extension from it.

## What counts as a check

- Switching to a Robinhood tab, opening Robinhood, or coming back to the
  browser with Robinhood showing.
- You have to stay for more than half a second, so flicking past the tab on
  the way to another one is free.
- Coming back within five seconds of leaving is the same check.
- Reloading, clicking around inside Robinhood and moving between two Robinhood
  tabs are not new checks.
- Only the account site (`robinhood.com`) counts. Help and marketing pages
  under `robinhood.com/us/` are left alone.

The toolbar button shows today's count, the last seven days and a
**Reset today** button.

## Turning it off

- **Pause:** click the toolbar button and flip the switch. While it is off the
  extension counts nothing, shows nothing and writes nothing. Flip it back
  whenever you like; your history is kept.
- **Disable or remove:** `chrome://extensions`, then the toggle or **Remove**
  on the Back to Work card. Nothing is left behind in the page or in the
  browser. Removing it deletes the tally.

## What it can and cannot do

- One permission: `storage`, to keep the tally in this browser.
- It runs only on `https://robinhood.com/*`.
- It does not read the page, your balances or anything you type. It does not
  touch the page's cookies or storage, and it makes no network requests. The
  whole thing is a few hundred lines of plain JavaScript in this folder, with
  no build step and no third-party code.
- It keeps four things in `chrome.storage.local`: the on/off switch, a count
  per day (the latest 60 days), when you were last on Robinhood, and the last
  joke shown.

## Changing things

- The jokes and the counts at which they change tone are in `messages.js`.
- The timings are at the top of `content.js`: how long the note stays
  (`SHOW_MS`), how soon a return counts again (`GRACE_MS`), and how long you
  must stay for a visit to count (`DWELL_MS`).
- Position, size and transparency are in the `CSS` block in `content.js`
  (`bottom`, `max-width` and the `background` alpha).

After editing, press the reload arrow on the extension's card in
`chrome://extensions`, then reload your Robinhood tab.

---

Not affiliated with or endorsed by Robinhood Markets, Inc. The jokes are
jokes, not financial advice.
