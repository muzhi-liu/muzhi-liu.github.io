/*
 * Back to Work: page script.
 *
 * Runs on robinhood.com tabs and does three things:
 *   1. notices when the tab comes in front of you (visible and focused),
 *   2. adds one to today's tally in chrome.storage.local,
 *   3. shows a small see-through note for a few seconds.
 *
 * It does not read the page, does not touch the page's own elements, cookies
 * or storage, and makes no network requests. The note sits in its own closed
 * shadow root, ignores the mouse (clicks pass straight through it), and is
 * taken off the page as soon as it fades.
 */
(() => {
  'use strict';

  const DWELL_MS = 600; // stay this long before it counts (so flicking past the tab does not)
  const GRACE_MS = 5000; // coming back within this long is the same check
  const SHOW_MS = 5000; // how long the note stays up
  const FADE_MS = 400;
  const LOAD_WAIT_MS = 3000; // on a fresh page load, wait at most this long for it to finish

  let present = false; // tab is visible AND its window has focus
  let counted = false; // this stretch of presence has been tallied (or merged into the last one)
  let enabled = true; // the popup's switch; re-read on every visit and kept live in between
  let arrivedAt = 0;
  let recent = 0; // in-memory twin of lastActiveAt, for when storage has not caught up
  let dwellTimer = 0;
  let recheckTimer = 0;
  let toastRun = 0; // bumped to cancel a note that is queued or showing
  let dead = false; // set once the extension is switched off, reloaded or removed

  // ---- presence -----------------------------------------------------------

  function alive() {
    try {
      return !dead && Boolean(chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function evaluate() {
    if (dead) return;
    if (!alive()) return shutDown();
    const now = document.visibilityState === 'visible' && document.hasFocus();
    if (now === present) return;
    present = now;
    if (now) arrive();
    else leave();
  }

  function arrive() {
    arrivedAt = Date.now();
    counted = false;
    clearTimeout(dwellTimer);
    dwellTimer = setTimeout(tally, DWELL_MS);
  }

  function leave() {
    clearTimeout(dwellTimer);
    removeToast();
    if (counted) stamp();
    counted = false;
  }

  // Focus and visibility events arrive in no fixed order; look now, and once
  // more a moment later in case the browser had not finished updating.
  function onSignal() {
    evaluate();
    clearTimeout(recheckTimer);
    recheckTimer = setTimeout(evaluate, 60);
  }

  // Remember when you were last here, so a quick return is not counted twice.
  function stamp() {
    if (!enabled) return; // paused means nothing is written at all
    recent = Date.now();
    if (!alive()) return;
    try {
      chrome.storage.local.set({ lastActiveAt: recent }).catch(() => {});
    } catch {
      shutDown();
    }
  }

  async function tally() {
    if (!present || !alive()) return;
    let state;
    try {
      state = await chrome.storage.local.get(BTW.DEFAULTS);
    } catch {
      return shutDown();
    }
    if (!present || dead) return;
    enabled = state.enabled !== false;
    if (!enabled) return; // paused: no counting, no notes, nothing written

    const now = Date.now();
    let last = Math.max(Number(state.lastActiveAt) || 0, recent);
    if (last > now + 60000) last = 0; // a clock that jumped backwards must not block counting
    const isNewCheck = arrivedAt - last >= GRACE_MS;

    counted = true;
    recent = now;
    const update = { lastActiveAt: now };
    let count = 0;
    let pick = null;
    if (isNewCheck) {
      const counts = BTW.prune(state.counts);
      const today = BTW.dayKey();
      count = (counts[today] || 0) + 1;
      counts[today] = count;
      pick = BTW.pickLine(count, state.lastLine);
      update.counts = counts;
      update.lastLine = pick.line;
    }
    try {
      await chrome.storage.local.set(update);
    } catch {
      return shutDown();
    }
    if (isNewCheck) queueToast(count, pick);
  }

  // ---- the note -----------------------------------------------------------

  const CSS = `
    :host {
      all: initial !important;
      position: fixed !important;
      left: 0 !important;
      right: 0 !important;
      bottom: 28px !important;
      z-index: 2147483647 !important;
      display: flex !important;
      justify-content: center !important;
      pointer-events: none !important;
    }
    .toast {
      box-sizing: border-box;
      display: flex;
      align-items: center;
      gap: 11px;
      max-width: min(480px, calc(100% - 32px));
      padding: 10px 18px 11px 14px;
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.18);
      background: rgba(20, 23, 28, 0.66);
      box-shadow: 0 6px 22px rgba(0, 0, 0, 0.2);
      color: #fff;
      font: 500 14px/1.35 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.45);
      opacity: 0;
      transform: translateY(10px);
      transition: opacity 0.22s ease-out, transform 0.22s ease-out;
    }
    .toast.in { opacity: 1; transform: none; }
    .toast.out { opacity: 0; transform: translateY(6px); transition-duration: 0.4s; }
    .emoji { flex: none; font-size: 22px; line-height: 1; }
    .text { min-width: 0; }
    .title {
      font-size: 11px;
      font-weight: 650;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      opacity: 0.78;
    }
    .line { margin-top: 1px; overflow-wrap: anywhere; text-wrap: balance; }
    @media (prefers-reduced-motion: reduce) {
      .toast, .toast.in, .toast.out { transform: none; }
    }
  `;

  let host = null;
  let hideTimer = 0;
  let removeTimer = 0;

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  // Show the note once the page has finished loading (or straight away if it already has).
  function queueToast(count, pick) {
    const run = ++toastRun;
    const show = () => {
      if (run === toastRun && present && !dead) showToast(count, pick);
    };
    if (document.readyState === 'complete') return show();
    let fired = false;
    const go = () => {
      if (fired) return;
      fired = true;
      clearTimeout(cap);
      window.removeEventListener('load', go);
      setTimeout(show, 150);
    };
    const cap = setTimeout(go, LOAD_WAIT_MS);
    window.addEventListener('load', go);
  }

  function showToast(count, pick) {
    removeToast();
    const run = ++toastRun;

    host = el('div');
    host.setAttribute('data-back-to-work', '');
    const root = host.attachShadow({ mode: 'closed' });
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS);
      root.adoptedStyleSheets = [sheet];
    } catch {
      root.append(el('style', '', CSS));
    }

    const toast = el('div', 'toast');
    toast.setAttribute('role', 'status');
    const emoji = el('span', 'emoji', pick.emoji);
    emoji.setAttribute('aria-hidden', 'true');
    const text = el('div', 'text');
    text.append(el('div', 'title', `Check #${count} today`), el('div', 'line', pick.line));
    toast.append(emoji, text);
    root.append(toast);

    (document.documentElement || document.body).append(host);
    void toast.offsetWidth; // let the starting state apply so the fade-in animates
    toast.classList.add('in');

    hideTimer = setTimeout(() => {
      if (run !== toastRun) return;
      toast.classList.replace('in', 'out');
      removeTimer = setTimeout(() => {
        if (run === toastRun) removeToast();
      }, FADE_MS);
    }, SHOW_MS);
  }

  function removeToast() {
    toastRun++;
    clearTimeout(hideTimer);
    clearTimeout(removeTimer);
    if (host) host.remove();
    host = null;
  }

  // ---- wiring -------------------------------------------------------------

  function onPageHide() {
    if (!present) return;
    present = false;
    leave();
  }

  function onStorageChanged(changes, area) {
    if (area !== 'local' || !changes.enabled) return;
    enabled = changes.enabled.newValue !== false;
    if (!enabled) {
      counted = false;
      removeToast();
    }
  }

  // The popup opens over this tab and takes focus; closing it gives focus back.
  // That round trip is not a new check, so note the moment the popup closes.
  function onPopup(port) {
    if (port.name !== 'btw-popup') return;
    port.onDisconnect.addListener(() => {
      if (dead) return;
      stamp();
    });
  }

  // Once the extension is switched off, reloaded or removed, this copy of the
  // script can no longer reach it. Leave the page exactly as it was found.
  function shutDown() {
    if (dead) return;
    dead = true;
    present = false;
    clearTimeout(dwellTimer);
    clearTimeout(recheckTimer);
    removeToast();
    document.removeEventListener('visibilitychange', onSignal);
    window.removeEventListener('focus', onSignal);
    window.removeEventListener('blur', onSignal);
    window.removeEventListener('pageshow', onSignal);
    window.removeEventListener('pagehide', onPageHide);
    try {
      chrome.storage.onChanged.removeListener(onStorageChanged);
      chrome.runtime.onConnect.removeListener(onPopup);
    } catch {
      // Already disconnected; nothing left to undo.
    }
  }

  document.addEventListener('visibilitychange', onSignal);
  window.addEventListener('focus', onSignal);
  window.addEventListener('blur', onSignal);
  window.addEventListener('pageshow', onSignal);
  window.addEventListener('pagehide', onPageHide);
  chrome.storage.onChanged.addListener(onStorageChanged);
  chrome.runtime.onConnect.addListener(onPopup);
  chrome.storage.local.get({ enabled: true }).then(
    (state) => {
      enabled = state.enabled !== false;
    },
    () => {}
  );
  evaluate();
})();
