/* Back to Work: helpers shared by the page script and the popup. */
const BTW = (() => {
  'use strict';

  // Everything the extension stores, in chrome.storage.local on this device.
  const DEFAULTS = Object.freeze({
    enabled: true, // the switch in the popup
    counts: {}, // one entry per local day, e.g. { "2026-11-13": 7 }
    lastActiveAt: 0, // when a Robinhood tab was last in front of you (ms)
    lastLine: '', // the last joke shown, so it is not repeated back to back
  });

  const KEEP_DAYS = 60;
  const DAY_KEY = /^\d{4}-\d{2}-\d{2}$/;

  // Local calendar day as YYYY-MM-DD.
  function dayKey(date = new Date()) {
    const pad = (n) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  // The last `n` local days, oldest first, ending today.
  function lastDays(n, from = new Date()) {
    const days = [];
    for (let i = n - 1; i >= 0; i--) {
      days.push(new Date(from.getFullYear(), from.getMonth(), from.getDate() - i));
    }
    return days;
  }

  // Drop anything that is not a day tally, and anything older than KEEP_DAYS days.
  function prune(counts) {
    const keys = Object.keys(counts || {})
      .filter((k) => DAY_KEY.test(k) && Number.isFinite(counts[k]) && counts[k] > 0)
      .sort()
      .slice(-KEEP_DAYS);
    const kept = {};
    for (const k of keys) kept[k] = counts[k];
    return kept;
  }

  return { DEFAULTS, dayKey, lastDays, prune };
})();
