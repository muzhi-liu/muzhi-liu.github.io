/*
 * Back to Work: the jokes.
 *
 * Edit freely. Each tier applies from its `from` count upward until the next
 * tier takes over. "{n}" is replaced with today's count. Lines of up to about
 * 60 characters fit on one row of the note.
 */
BTW.tiers = [
  {
    from: 1,
    emoji: "👀",
    verdict: "Perfectly reasonable.",
    lines: [
      "First look of the day. Make it count, then back to work.",
      "Totally reasonable. That's the last time I'll say so.",
      "Good to see you. Your to-do list was asking after you.",
    ],
  },
  {
    from: 2,
    emoji: "👀",
    verdict: "A healthy curiosity.",
    lines: [
      "Still stocks. Still there. Back to work.",
      "Nothing happened. Go back to work.",
      "The number wiggled. It does that. Back to work.",
      "Your portfolio says hi. Your to-do list says hi louder.",
      "A watched stock never moons.",
      "Back so soon? It hasn't had time to miss you.",
      "About the same as last time, give or take a wiggle.",
    ],
  },
  {
    from: 5,
    emoji: "🙃",
    verdict: "Getting a little clingy.",
    lines: [
      "Staring doesn't make it go up. We checked.",
      "Compound interest works best unsupervised.",
      "You again? The market didn't notice you left.",
      "Refreshing is not a strategy.",
      "The chart moved a hair. Riveting. Back to work.",
      "Fun fact: it moves whether or not you're looking.",
      "This tab is not your job. Probably.",
      "Somewhere an index fund is napping. Be the index fund.",
      "The candles will still be there after one more paragraph.",
    ],
  },
  {
    from: 10,
    emoji: "😬",
    verdict: "The stocks feel watched.",
    lines: [
      "At this point you're not investing, you're babysitting.",
      "Double digits. The stocks are starting to feel watched.",
      "You've looked more often than the price has moved.",
      "{n} looks today. Even the ticker thinks that's a lot.",
      "Your future self called. They'd like that hour back.",
      "It's a portfolio, not a newborn. It can be left alone.",
      "Bold to assume it changed since the last time.",
      "Deep breath. Close the tab. Open the work.",
      "You could've learned a language by now. A small one.",
    ],
  },
  {
    from: 20,
    emoji: "🚨",
    verdict: "This is a lifestyle now.",
    lines: [
      "This is no longer checking. This is a relationship.",
      "New personal record. Not the good kind.",
      "Blink twice if the chart is holding you hostage.",
      "Back. To. Work. Please. I'm begging.",
      "If checking paid dividends, you could retire today.",
      "The stocks have asked for a little privacy.",
      "I'm not mad. I'm just counting. {n}, by the way.",
      "At this rate you'll need a second monitor for regret.",
    ],
  },
];

// The tier that applies to a given count (null for zero).
BTW.tierFor = (count) => {
  let tier = null;
  for (const t of BTW.tiers) if (count >= t.from) tier = t;
  return tier;
};

// A random line for this count, avoiding the one shown last time.
BTW.pickLine = (count, lastLine) => {
  const tier = BTW.tierFor(count);
  if (!tier) return { emoji: "👀", line: "" };
  let pool = tier.lines.map((line) => line.replace("{n}", String(count)));
  if (pool.length > 1) pool = pool.filter((line) => line !== lastLine);
  return { emoji: tier.emoji, line: pool[Math.floor(Math.random() * pool.length)] };
};

// One-line verdict for the popup.
BTW.verdict = (count) => {
  const tier = BTW.tierFor(count);
  return tier ? tier.verdict : "Nothing yet. Suspiciously disciplined.";
};
