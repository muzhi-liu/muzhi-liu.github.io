/* Back to Work: the toolbar popup (today's count, the past week, the on/off switch). */
(async () => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const state = await chrome.storage.local.get(BTW.DEFAULTS);

  function render() {
    const counts = state.counts || {};
    const on = state.enabled !== false;
    const today = counts[BTW.dayKey()] || 0;

    $('enabled').checked = on;
    document.body.classList.toggle('paused', !on);
    $('count').textContent = String(today);
    $('unit').textContent = today === 1 ? 'Robinhood check today' : 'Robinhood checks today';
    $('verdict').textContent = on ? BTW.verdict(today) : 'Paused. Not counting, no reminders.';
    $('reset').disabled = today === 0;

    const days = BTW.lastDays(7);
    const values = days.map((d) => counts[BTW.dayKey(d)] || 0);
    const max = Math.max(1, ...values);
    const week = $('week');
    week.replaceChildren();
    days.forEach((d, i) => {
      const n = values[i];
      const li = document.createElement('li');
      if (i === days.length - 1) li.className = 'today';
      const label = d.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });
      li.title = `${label}: ${n} ${n === 1 ? 'check' : 'checks'}`;

      const num = document.createElement('span');
      num.className = 'num';
      num.textContent = n ? String(n) : '';
      const bar = document.createElement('span');
      bar.className = 'bar';
      bar.style.height = `${Math.round((n / max) * 44)}px`;
      const day = document.createElement('span');
      day.className = 'day';
      day.textContent = d.toLocaleDateString(undefined, { weekday: 'narrow' });

      li.append(num, bar, day);
      week.append(li);
    });
  }

  render();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const [key, change] of Object.entries(changes)) {
      state[key] = change.newValue === undefined ? BTW.DEFAULTS[key] : change.newValue;
    }
    render();
  });

  $('enabled').addEventListener('change', (event) => {
    chrome.storage.local.set({ enabled: event.target.checked });
  });

  $('reset').addEventListener('click', async () => {
    const { counts } = await chrome.storage.local.get({ counts: {} });
    delete counts[BTW.dayKey()];
    await chrome.storage.local.set({ counts });
  });

  // Let the tab underneath know the popup is open, so that getting focus back
  // when the popup closes is not mistaken for a new check. Tabs that are not
  // running the page script simply do not answer.
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id != null) {
      const port = chrome.tabs.connect(tab.id, { name: 'btw-popup' });
      port.onDisconnect.addListener(() => void chrome.runtime.lastError);
    }
  } catch {
    // No tab to talk to; nothing to do.
  }
})();
